Data collected by US Government vessel and staff.

All of the files listed here have these properties:

- License: None needed.  Public domain.
- Copyright: None.  Public domain. 

Sample files with GSF version:

- Ver 2.02 - [R1SB\_2002\_2002-119\_438\_2024](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/rainier/H11121/multibeam/data/version1/MB/R1SB_2002_2002-119_438_2024.mb121.gz)
- Ver 2.02 - [14VB_2001-248\_244\_2013](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/whiting/H11077/multibeam/data/version1/MB/14VB_2001-248_244_2013.mb121.gz)
- Ver 2.03 - [RA01\_99\_1999-147\_011\_1723](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/rainier/H10866/multibeam/data/version1/MB/RA01_99_1999-147_011_1723.mb121.gz)
- Ver 2.03 - [RU00\_SB\_2003-112\_845\_2036](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/rude/F00490/multibeam/data/version1/MB/RU00_SB_2003-112_845_2036.mb121.gz)
- Ver 2.03 - [518](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/nancy_foster/NF0706/multibeam/data/version2/MB/518.gsf.mb121.gz)
- Ver 2.09 - [6\_184\_1440](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/bay_hydrographer/H10934/multibeam/data/version1/MB/6_184_1440.mb121.gz)
- Ver 2.09 - [052-1320](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/nancy_foster/NF0406/multibeam/data/version1/MB/BuckIsland_StCroix/052-1320.mb121.gz)
- Ver 3.06 - [0175\_20150322\_232639\_EX1502L2\_MB](http://surveys.ngdc.noaa.gov/mgg/MB/ocean/okeanos_explorer/EX1502L2/multibeam/data/version2/MB/em302/0175_20150322_232639_EX1502L2_MB.gsf.mb121.gz)
